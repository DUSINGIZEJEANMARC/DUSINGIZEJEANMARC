<!-- resources/views/layouts/app.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Movie Ticket Booking</title>
    <!-- Add your CSS and other stylesheets here -->
</head>
<body>
    <div class="container">
        @yield('content')
    </div>
</body>
</html>
